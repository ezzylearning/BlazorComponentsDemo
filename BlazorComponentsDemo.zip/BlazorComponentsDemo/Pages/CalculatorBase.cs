﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;

namespace BlazorComponentsDemo.Pages
{
    public class CalculatorBase : ComponentBase
    {
        public int number1 = 0;
        public int number2 = 0;
        public int total = 0;

        public void Calculate()
        {
            total = number1 + number2;
        }
    }
}
